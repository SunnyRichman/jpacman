package nl.tudelft.jpacman.board;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BoardTest {

    private Board board;
    Square square = new BasicSquare();
    Square[][] grid = new Square[1][1];
    @BeforeEach
    void setup(){
        grid[0][0] = square;
        board = new Board(grid);
    }

    @Test
    void testBoard(){
        assertEquals(square, board.squareAt(0, 0));
    }

    @Test
    void testNullSquare(){
        grid[0][0] = null;
        assertThrows(java.lang.AssertionError.class, () -> board.squareAt(0, 0));
//        assertEquals(grid[0][0], board.squareAt(0, 0));
    }
}
