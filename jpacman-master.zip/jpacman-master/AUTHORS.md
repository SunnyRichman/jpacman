Authors
=======

JPacman is created and maintained by Arie van Deursen.

Over the years, many people have contributed to its code base, whom we would
like to acknowledge:

Jeroen Roosen
Tim van der Lippe
Liam Clark
Adrien Coppens
Moritz Beller
Michael de Jong
Miguel Mendes
Maarten Sijm
Lotte Steenbrink
Lars Stegman
huang-da
Aaron Ang